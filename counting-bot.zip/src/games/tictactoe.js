const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const store = require('./store');
const render = require('./render');
const { png, mention, reject, shuffle, stopButton, endButtons, textPayload } = require('./common');
const elo = require('./elo');
const v2 = require('../v2');

const info = {
    id: 'tictactoe', label: 'Tic tac toe', emoji: '\u2B55', short: '2 players, first to three in a row wins',
    how: 'For 2 players. Someone accepts your invitation, a random player starts, and you take turns pressing a numbered square on a shared board. First to three in a row wins.',
};
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function winner(b) { for (const l of LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[1]] === b[l[2]]) return { mark: b[l[0]], line: l }; return null; }

function payload(game) {
    const s = game.state, w = winner(s.board), full = s.board.every(Boolean), over = !!w || full;
    if (game.phase === 'over' && over) {   // a finished game leaves one line of text instead of the board
        const loser = w ? (w.mark === 'x' ? s.o : s.x) : null;
        return textPayload(`${info.emoji} **${info.label}**: ${w ? `\u{1F3C6} ${mention(w.mark === 'x' ? s.x : s.o)} beat ${mention(loser)}!` : `${mention(s.x)} and ${mention(s.o)} drew.`}${game.eloResult ? `\n${elo.resultLine(game.eloResult)}` : ''}`);
    }
    const turnId = s.turn === 'x' ? s.x : s.o;
    const status = w ? `\u{1F3C6} ${mention(w.mark === 'x' ? s.x : s.o)} wins!` : full ? "It's a draw!" : `${s.turn === 'x' ? '\u274C' : '\u2B55'} ${mention(turnId)} plays next`;
    const players = `\u274C ${elo.withRating(game, s.x)} **vs** \u2B55 ${elo.withRating(game, s.o)}`;
    const embed = v2.card({ title: 'Tic-Tac-Toe', blocks: [players, `${status}${game.eloResult ? `\n${elo.resultLine(game.eloResult)}` : ''}`], image: 'attachment://board.png' });
    const rows = [0, 1, 2].map(r => new ActionRowBuilder().addComponents([0, 1, 2].map(c => {
        const i = r * 3 + c, v = s.board[i];
        return new ButtonBuilder().setCustomId(`g:${game.id}:m:${i}`).setLabel(v ? v.toUpperCase() : String(i + 1)).setStyle(v === 'x' ? ButtonStyle.Danger : v === 'o' ? ButtonStyle.Primary : ButtonStyle.Secondary).setDisabled(!!v || over);
    })));
    if (!over) rows.push(new ActionRowBuilder().addComponents(...endButtons(game)));
    return { embeds: [embed], components: rows, files: [png(render.tictactoe(s.board, w?.line), 'board.png')], attachments: [] };
}

async function start(interaction, { postInvite }) { await postInvite(interaction, 'tictactoe'); }

async function onAccept(interaction, game) {
    const [x, o] = shuffle([game.hostId, game.guestId]);   // X always moves first, and who gets X is random
    game.state = { board: Array(9).fill(''), x, o, turn: 'x' };
    store.save(game);
    return interaction.update(payload(game));
}

async function handle(interaction, game, action, args) {
    if (action !== 'm' || game.phase !== 'play') return reject(interaction, 'This game is over.');
    const s = game.state, i = Number(args[0]), uid = interaction.user.id;
    if (uid !== s.x && uid !== s.o) return reject(interaction, "You're not in this game.");
    if (uid !== (s.turn === 'x' ? s.x : s.o)) return reject(interaction, "It's not your turn.");
    if (!(i >= 0 && i < 9) || s.board[i]) return reject(interaction, 'That square is taken.');
    s.board[i] = s.turn;
    if (winner(s.board) || s.board.every(Boolean)) {
        game.phase = 'over'; const w = winner(s.board);
        game.eloResult = await elo.finish(game, w ? (w.mark === 'x' ? s.x : s.o) : null);
        const p = payload(game); store.remove(game); return interaction.update(p);
    }
    s.turn = s.turn === 'x' ? 'o' : 'x';
    store.save(game);
    return interaction.update(payload(game));
}

const waitingOn = game => [game.state.turn === 'x' ? game.state.x : game.state.o];
const moved = game => ({ [game.state.x]: game.state.board.filter(v => v === 'x').length, [game.state.o]: game.state.board.filter(v => v === 'o').length });

module.exports = { info, start, onAccept, handle, payload, winner, moved, waitingOn };
